<?php
$choix_date_debut = "1/1/2009" ;
$choix_date_fin  = "31/12/2022" ;
$periode_affiche  = "60" ;
$choix_selection_locataire  = 0 ;
$choix_selection_logement  = 0 ;
$liste_couleur[0]  = 1 ;
$listing_complet = "off" ;
$locataire_complet = "off" ;
$avec_infobulle = "off" ;
$format_date_export = "JJ/MM/AAAA" ;

?>