<?php


header('Location: /');
exit;

?>