<?php
//***************************************************************************************************
// fichier contenant la liste des logements et des locataires
//***************************************************************************************************
 


$fin_tableau_logement = true;

$derniere_cle_tableau_logement = "0";

?>