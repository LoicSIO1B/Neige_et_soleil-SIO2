<?php
$date_maj_calendrier["fr"]= "08 D�cembre 2010" ;
$date_maj_calendrier["all"]= "08 Dezember 2010" ;
$date_maj_calendrier["eng"]= "08 December 2010" ;
$date_maj_calendrier["it"]= "08 Dicembre 2010" ;
$date_maj_calendrier["esp"]= "08 Diciembre 2010" ;


?>