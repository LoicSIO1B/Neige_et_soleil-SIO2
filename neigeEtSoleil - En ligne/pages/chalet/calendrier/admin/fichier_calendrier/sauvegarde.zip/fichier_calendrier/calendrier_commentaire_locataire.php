<?php
//***************************************************************************************************
// fichier contenant la liste des commentaires locataires
//***************************************************************************************************
// la variable $fin_tableau_commentaire_locataire = true;  doit toujours �tre plac� en fin de fichier
//*************************************************************************************************** 

$derniere_cle_tableau_commentaire = "0";
$fin_tableau_commentaire_locataire = true;

?>