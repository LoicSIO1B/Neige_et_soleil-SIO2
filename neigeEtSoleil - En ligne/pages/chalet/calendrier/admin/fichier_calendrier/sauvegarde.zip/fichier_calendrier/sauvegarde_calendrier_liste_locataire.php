<?php
//***************************************************************************************************
// fichier contenant la liste des logements et des locataires
//***************************************************************************************************
// la variable $fin_tableau_locataire = true;  doit toujours �tre plac� en fin de fichier
//*************************************************************************************************** 
$nom_locataire[0]= "Tous" ;
$prenom_locataire[0]= "" ;

$derniere_cle_tableau_locataire = "0";
$fin_tableau_locataire = true;

?>