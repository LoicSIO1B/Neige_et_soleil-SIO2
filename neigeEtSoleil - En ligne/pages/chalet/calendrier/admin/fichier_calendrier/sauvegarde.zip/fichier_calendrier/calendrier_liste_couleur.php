<?php
//***************************************************************************************************
// fichier contenant la liste des logements et des locataires
//*************************************************************************************************** 

$couleur_reserve[1] = "#FF0000" ;
$url_couleur_reserve[1] = "" ;
$intitule_couleur_reserve[1] = "R�serv�" ;
$couleur_texte_jour_reserve[1] = "#FFFFFF" ;
$couleur_affiche_tarif[1] = false ;
$couleur_date_clic[1] = false ;
$couleur_invisible[1] = false ;
$date_couleur_barre[1] = true ;
$date_couleur_disponible[1] = false ;

$couleur_reserve[3] = "#C0D921" ;
$url_couleur_reserve[3] = "" ;
$intitule_couleur_reserve[3] = "Basse saison" ;
$couleur_texte_jour_reserve[3] = "#FFFFFF" ;
$couleur_affiche_tarif[3] = true ;
$couleur_date_clic[3] = true ;
$couleur_invisible[3] = false ;
$date_couleur_barre[3] = false ;
$date_couleur_disponible[3] = true ;

$couleur_reserve[4] = "#FFE24F" ;
$url_couleur_reserve[4] = "" ;
$intitule_couleur_reserve[4] = "Saison moyenne" ;
$couleur_texte_jour_reserve[4] = "#0D0D0D" ;
$couleur_affiche_tarif[4] = true ;
$couleur_date_clic[4] = true ;
$couleur_invisible[4] = false ;
$date_couleur_barre[4] = false ;
$date_couleur_disponible[4] = true ;

$couleur_reserve[5] = "#FF8812" ;
$url_couleur_reserve[5] = "" ;
$intitule_couleur_reserve[5] = "Haute saison" ;
$couleur_texte_jour_reserve[5] = "#FFFFFF" ;
$couleur_affiche_tarif[5] = true ;
$couleur_date_clic[5] = false ;
$couleur_invisible[5] = false ;
$date_couleur_barre[5] = false ;
$date_couleur_disponible[5] = true ;


$fin_tableau_couleur = true;

?>